var cadena = "################";
  var cambio='';
  document.getElementById("noTarjeta1").value=cadena.substring(0,4)+"   "+ cadena.substring(4,8)+"   "+ cadena.substring(8,12)+"   "+cadena.substring(12,16);
  
  //Limpia selección de campo
  function limpiarClase(){
    document.querySelectorAll('.seleccionado').forEach((elm,indice)=>{
      elm.className=elm.className.replace('seleccionado','');
    });
  }

  //Agrega clase a selección de campo
  function aplicarSeleccion(idCampo){
    limpiarClase();
    document.getElementById(idCampo).className+=" seleccionado"; 
  }

  //Captura de número de tarjeta
  function capturaNoTarjeta(input)
  {
    //Acepta solo números
    input.value = input.value.replace(/[^0-9]/g, '');
    console.log(input.value.length);
    var numCaracteres=input.value.length;
    cambio= input.value + cadena.substring(numCaracteres);
    cambio =cambio.substring(0,4)+"  "+ cambio.substring(4,8).toString().replace(/\d(?=\d{0})/g,"*")+"   "+ cambio.substring(8,12).toString().replace(/\d(?=\d{0})/g,"*")+"  "+cambio.substring(12,16);
    document.getElementById(input.id+"1").value=cambio;
    document.getElementById(input.id+"1").classList.add('animated', 'flipInX')

    
    //Cambia logo de tarjeta
    var image = document.getElementById('logo');
    if ( cambio.substring(0,1) == "3"){
        image.src = "assets/img/LogoAmericanExpress.svg";
      }else if( cambio.substring(0,1) == "4"){
        image.src = "assets/img/logoVisa.svg";
      }else if( cambio.substring(0,2) == "51" || cambio.substring(0,2) == "52" || cambio.substring(0,2) == "53" || cambio.substring(0,2) == "54"){
        image.src = "assets/img/logoMasterCard.svg";
      }else{
        image.src = "assets/img/logoDiscover.svg";
    }
  }

  //Captura nombre del usuario de la tarjeta
  function capturaNombre(input)
  {
    document.getElementById(input.id+"1").value=input.value;
    document.getElementById(input.id+"1").classList.add('animated', 'lightSpeedIn');
  }

  //Captura fecha de expedición
  function capturaDate(input)
  {
    console.log(input.value);
    document.getElementById(input.id+"1").value=input.value;
    document.getElementById(input.id+"1").parentNode.parentNode.parentNode.className="contDate seleccionado";
    document.getElementById(input.id+"1").classList.add('animated', 'flipInX');
  }

  //Captura CVC y gira tarjeta
  function capturaCVC(input)
  {
    input.value = input.value.replace(/[^0-9]/g, '');
    var cambioCVC=input.value;
    cambioCVC =cambioCVC.toString().replace(/\d(?=\d{0})/g,"*");
    document.getElementById(input.id+"1").value=cambioCVC;
    //Limita a 4 caracteres el CVC
    input.value = input.value.slice(0,4); 
    //Gira tarjeta
    var contenedorBack = document.getElementById("contenedor");
    contenedorBack.className ="flip vuelta";
  }

  //Regresa tarjeta a Front
  function frontCVC()
  {
    var contenedorBack = document.getElementById("contenedor");
    contenedorBack.classList.remove("vuelta");
  }



